#include	"kamship.h"

void		kamship_core(KamShip* k)
{
  (void)k;
}
