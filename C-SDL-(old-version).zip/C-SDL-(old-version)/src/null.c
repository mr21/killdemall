void		null(void* p)
{
  (void)p;
}
