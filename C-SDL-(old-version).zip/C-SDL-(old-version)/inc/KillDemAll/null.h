#ifndef		NULL_H
#define		NULL_H

void		null(void*);

#endif
