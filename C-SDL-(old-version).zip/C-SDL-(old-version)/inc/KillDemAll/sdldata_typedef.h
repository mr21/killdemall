#ifndef		SDLDATA_TYPEDEF_H
#define		SDLDATA_TYPEDEF_H

typedef struct	SDLData	SDLData;

#endif
