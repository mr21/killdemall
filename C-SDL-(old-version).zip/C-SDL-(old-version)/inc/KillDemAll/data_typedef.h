#ifndef		DATA_TYPEDEF_H
#define		DATA_TYPEDEF_H

typedef struct	Data	Data;

#endif
