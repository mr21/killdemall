#ifndef		RENDER_H
#define		RENDER_H

#include	"SDLazy.h"

void		render(void);
void		pos_onscreen(v2f* v, v2f* cam, v2f* pos);

#endif
