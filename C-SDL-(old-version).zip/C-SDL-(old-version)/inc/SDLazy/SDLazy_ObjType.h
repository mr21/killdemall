#ifndef			SDLAZY_OBJTYPE_H
# define		SDLAZY_OBJTYPE_H

typedef			enum
  {
    SURFACE,
    SPRITE,
    ANIM,
    BUTTON
  }			eObjType;

#endif
