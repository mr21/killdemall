KillDemAll
==========

_Kill Dem All_ est un mini jeu SDL (utilisant la lib' sur laquelle je travaille _SDLazy_)

_Envie de tester ?_  
Okay c'est cool alors faites directement :
`cd /tmp && git clone git://github.com/Mr21/KillDemAll.git && cd Kill* && clear && cat R* && ./K*`  

Les controles pour le moment sont :  

* __Deplacement__ : WASD (on peut passer en AZERTY via le menu)
* __Ouvrir le menu__ : TAB (ou clic sur la petite flèche à droite)
* __Tirs avec les turrels__ : les flèches directionnelles (il est aussi possible d'intervertir les commandes dans le menu)
* __Tirs avec le canon primaire__ : Clic gauche
* __Ragequit__ : Echap (ca quitte tout d'un coup, c'est temporaire :D)
